fuzzy-el
========

Moved to <https://github.com/auto-complete/fuzzy-el>
